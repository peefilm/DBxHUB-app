import { users, participants, giveaways, winners, type User, type InsertUser, type Participant, type InsertParticipant, type Giveaway, type InsertGiveaway, type Winner } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createParticipant(participant: InsertParticipant): Promise<Participant>;
  getParticipantsByGiveaway(giveawayId: number): Promise<Participant[]>;
  getParticipantByEmailAndGiveaway(email: string, giveawayId: number): Promise<Participant | undefined>;
  
  createGiveaway(giveaway: InsertGiveaway): Promise<Giveaway>;
  getActiveGiveaway(): Promise<Giveaway | undefined>;
  updateGiveaway(id: number, updates: Partial<Giveaway>): Promise<Giveaway | undefined>;
  
  getRecentWinners(limit?: number): Promise<(Winner & { participantName: string })[]>;
  createWinner(winner: { participantId: number; giveawayId: number; prizeAmount: number }): Promise<Winner>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private participants: Map<number, Participant>;
  private giveaways: Map<number, Giveaway>;
  private winners: Map<number, Winner>;
  private currentUserId: number;
  private currentParticipantId: number;
  private currentGiveawayId: number;
  private currentWinnerId: number;

  constructor() {
    this.users = new Map();
    this.participants = new Map();
    this.giveaways = new Map();
    this.winners = new Map();
    this.currentUserId = 1;
    this.currentParticipantId = 1;
    this.currentGiveawayId = 1;
    this.currentWinnerId = 1;
    
    // Initialize with an active giveaway
    this.initializeActiveGiveaway();
  }

  private initializeActiveGiveaway() {
    const endTime = new Date();
    endTime.setHours(endTime.getHours() + 2);
    endTime.setMinutes(endTime.getMinutes() + 34);
    
    const giveaway: Giveaway = {
      id: this.currentGiveawayId++,
      title: "การแจกเงินประจำวัน",
      prizeAmount: 50000,
      participantCount: 2847,
      winnerCount: 50,
      endTime,
      isActive: true,
    };
    
    this.giveaways.set(giveaway.id, giveaway);
    
    // Add some mock recent winners
    const mockParticipants = [
      { id: 1, name: "สมชาย ใ.", email: "somchai@example.com", phone: "0812345678", registeredAt: new Date(), giveawayId: 1 },
      { id: 2, name: "สุภา ก.", email: "supa@example.com", phone: "0887654321", registeredAt: new Date(), giveawayId: 1 },
      { id: 3, name: "วิทยา ส.", email: "witaya@example.com", phone: "0856789012", registeredAt: new Date(), giveawayId: 1 }
    ];
    
    mockParticipants.forEach(p => this.participants.set(p.id, p));
    this.currentParticipantId = 4;
    
    const mockWinners = [
      { id: 1, participantId: 1, giveawayId: 1, prizeAmount: 1250, wonAt: new Date() },
      { id: 2, participantId: 2, giveawayId: 1, prizeAmount: 850, wonAt: new Date() },
      { id: 3, participantId: 3, giveawayId: 1, prizeAmount: 2100, wonAt: new Date() }
    ];
    
    mockWinners.forEach(w => this.winners.set(w.id, w));
    this.currentWinnerId = 4;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createParticipant(insertParticipant: InsertParticipant): Promise<Participant> {
    const id = this.currentParticipantId++;
    const participant: Participant = {
      ...insertParticipant,
      id,
      registeredAt: new Date(),
    };
    this.participants.set(id, participant);
    
    // Update participant count in giveaway
    const giveaway = this.giveaways.get(insertParticipant.giveawayId);
    if (giveaway) {
      giveaway.participantCount += 1;
      this.giveaways.set(giveaway.id, giveaway);
    }
    
    return participant;
  }

  async getParticipantsByGiveaway(giveawayId: number): Promise<Participant[]> {
    return Array.from(this.participants.values()).filter(
      (participant) => participant.giveawayId === giveawayId,
    );
  }

  async getParticipantByEmailAndGiveaway(email: string, giveawayId: number): Promise<Participant | undefined> {
    return Array.from(this.participants.values()).find(
      (participant) => participant.email === email && participant.giveawayId === giveawayId,
    );
  }

  async createGiveaway(insertGiveaway: InsertGiveaway): Promise<Giveaway> {
    const id = this.currentGiveawayId++;
    const giveaway: Giveaway = {
      ...insertGiveaway,
      id,
      participantCount: 0,
      isActive: true,
    };
    this.giveaways.set(id, giveaway);
    return giveaway;
  }

  async getActiveGiveaway(): Promise<Giveaway | undefined> {
    return Array.from(this.giveaways.values()).find(
      (giveaway) => giveaway.isActive && giveaway.endTime > new Date(),
    );
  }

  async updateGiveaway(id: number, updates: Partial<Giveaway>): Promise<Giveaway | undefined> {
    const giveaway = this.giveaways.get(id);
    if (!giveaway) return undefined;
    
    const updatedGiveaway = { ...giveaway, ...updates };
    this.giveaways.set(id, updatedGiveaway);
    return updatedGiveaway;
  }

  async getRecentWinners(limit = 10): Promise<(Winner & { participantName: string })[]> {
    const recentWinners = Array.from(this.winners.values())
      .sort((a, b) => b.wonAt.getTime() - a.wonAt.getTime())
      .slice(0, limit);
    
    return recentWinners.map(winner => {
      const participant = this.participants.get(winner.participantId);
      return {
        ...winner,
        participantName: participant?.name || "ไม่ระบุชื่อ"
      };
    });
  }

  async createWinner(winner: { participantId: number; giveawayId: number; prizeAmount: number }): Promise<Winner> {
    const id = this.currentWinnerId++;
    const newWinner: Winner = {
      ...winner,
      id,
      wonAt: new Date(),
    };
    this.winners.set(id, newWinner);
    return newWinner;
  }
}

export const storage = new MemStorage();
