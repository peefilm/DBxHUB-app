import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertParticipantSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get active giveaway
  app.get("/api/giveaway/active", async (req, res) => {
    try {
      const giveaway = await storage.getActiveGiveaway();
      if (!giveaway) {
        return res.status(404).json({ message: "ไม่มีการแจกที่เปิดอยู่ในขณะนี้" });
      }
      res.json(giveaway);
    } catch (error) {
      res.status(500).json({ message: "เกิดข้อผิดพลาดในการดึงข้อมูลการแจก" });
    }
  });

  // Register for giveaway
  app.post("/api/giveaway/register", async (req, res) => {
    try {
      const validatedData = insertParticipantSchema.parse(req.body);
      
      // Check if active giveaway exists
      const activeGiveaway = await storage.getActiveGiveaway();
      if (!activeGiveaway) {
        return res.status(400).json({ message: "ไม่มีการแจกที่เปิดอยู่ในขณะนี้" });
      }
      
      // Check if already registered
      const existingParticipant = await storage.getParticipantByEmailAndGiveaway(
        validatedData.email,
        activeGiveaway.id
      );
      
      if (existingParticipant) {
        return res.status(400).json({ message: "อีเมลนี้ได้ลงทะเบียนแล้ว" });
      }
      
      // Create participant with active giveaway ID
      const participant = await storage.createParticipant({
        ...validatedData,
        giveawayId: activeGiveaway.id
      });
      
      res.json({ 
        message: "ลงทะเบียนสำเร็จ! ขอบคุณที่เข้าร่วมการแจกเงิน",
        participant
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "ข้อมูลไม่ถูกต้อง",
          errors: error.errors
        });
      }
      res.status(500).json({ message: "เกิดข้อผิดพลาดในการลงทะเบียน" });
    }
  });

  // Get recent winners
  app.get("/api/winners/recent", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const winners = await storage.getRecentWinners(limit);
      res.json(winners);
    } catch (error) {
      res.status(500).json({ message: "เกิดข้อผิดพลาดในการดึงข้อมูลผู้ชนะ" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
