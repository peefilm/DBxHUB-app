import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const participants = pgTable("participants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  registeredAt: timestamp("registered_at").defaultNow().notNull(),
  giveawayId: integer("giveaway_id").notNull(),
});

export const giveaways = pgTable("giveaways", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  prizeAmount: integer("prize_amount").notNull(),
  participantCount: integer("participant_count").default(0).notNull(),
  winnerCount: integer("winner_count").default(50).notNull(),
  endTime: timestamp("end_time").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

export const winners = pgTable("winners", {
  id: serial("id").primaryKey(),
  participantId: integer("participant_id").notNull(),
  giveawayId: integer("giveaway_id").notNull(),
  prizeAmount: integer("prize_amount").notNull(),
  wonAt: timestamp("won_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertParticipantSchema = createInsertSchema(participants).pick({
  name: true,
  email: true,
  phone: true,
  giveawayId: true,
});

export const insertGiveawaySchema = createInsertSchema(giveaways).pick({
  title: true,
  prizeAmount: true,
  winnerCount: true,
  endTime: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertParticipant = z.infer<typeof insertParticipantSchema>;
export type Participant = typeof participants.$inferSelect;
export type InsertGiveaway = z.infer<typeof insertGiveawaySchema>;
export type Giveaway = typeof giveaways.$inferSelect;
export type Winner = typeof winners.$inferSelect;
