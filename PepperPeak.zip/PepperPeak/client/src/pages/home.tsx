import { useQuery } from "@tanstack/react-query";
import { Gift, Scale3d, HandHelping, Heart, CheckCircle, TriangleAlert, Rocket, Play, Coins, Clock, Phone, Mail, Facebook, Twitter, Instagram, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CountdownTimer } from "@/components/countdown-timer";
import { GiveawayForm } from "@/components/giveaway-form";
import type { Giveaway, Winner } from "@shared/schema";

export default function Home() {
  const { data: giveaway, isLoading: giveawayLoading } = useQuery<Giveaway>({
    queryKey: ["/api/giveaway/active"],
  });

  const { data: recentWinners, isLoading: winnersLoading } = useQuery<(Winner & { participantName: string })[]>({
    queryKey: ["/api/winners/recent"],
  });

  const scrollToSection = (sectionId: string) => {
    window.open('https://www.youtube.com/watch?v=dQw4w9WgXcQ', '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <nav className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-emerald-500 rounded-xl flex items-center justify-center">
                <Gift className="text-white text-lg" />
              </div>
              <span className="text-2xl font-bold text-emerald-700">PeppaPeak</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-primary transition-colors font-medium">หน้าแรก</button>
              <button onClick={() => scrollToSection('giveaway')} className="text-gray-700 hover:text-primary transition-colors font-medium">แจกเงิน</button>
              <button onClick={() => scrollToSection('allah-hala')} className="text-gray-700 hover:text-primary transition-colors font-medium">Allah Hala</button>
              <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-primary transition-colors font-medium">เกี่ยวกับ</button>
              <Button className="bg-primary hover:bg-primary/90 text-white px-6 py-2 font-medium">เข้าสู่ระบบ</Button>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative bg-gradient-to-br from-emerald-50 via-white to-teal-50 py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-in slide-in-from-left duration-700">
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                แจกเงิน<span className="text-primary">ฟรี</span><br />
                ทุกวันกับ<br />
                <span className="bg-gradient-to-r from-primary to-orange-500 bg-clip-text text-transparent">PeppaPeak</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                แพลตฟอร์มแจกเงินออนไลน์ที่ได้รับความไว้วางใจ มีระบบความปลอดภัยสูง 
                และโอกาสชนะที่ยุติธรรมสำหรับทุกคน
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={() => scrollToSection('giveaway')}
                  className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg font-semibold"
                  size="lg"
                >
                  <Rocket className="mr-2" />
                  เริ่มร่วมสนุก
                </Button>
                <Button 
                  variant="outline"
                  className="px-8 py-4 text-lg font-semibold border-2"
                  size="lg"
                >
                  <Play className="mr-2" />
                  ดูวิธีการใช้งาน
                </Button>
              </div>
            </div>
            
            <div className="relative animate-in slide-in-from-right duration-700">
              <Card className="shadow-2xl">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-gray-900">แดชบอร์ดของคุณ</h3>
                    <div className="flex space-x-2">
                      <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                      <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                      <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="bg-gradient-to-r from-emerald-100 to-teal-100 p-4 rounded-xl">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">ยอดรวมที่ได้รับ</span>
                        <Coins className="text-orange-500 animate-bounce" />
                      </div>
                      <div className="text-2xl font-bold text-primary mt-1">฿12,580</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-600">การแจกครั้งถัดไป</div>
                        <div className="text-lg font-semibold text-gray-900 mt-1">2 ชั่วโมง</div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-sm text-gray-600">ผู้เข้าร่วม</div>
                        <div className="text-lg font-semibold text-gray-900 mt-1">
                          {giveaway?.participantCount?.toLocaleString() || "1,247"}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Allah Hala Section */}
      <section id="allah-hala" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Allah Hala</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-orange-500 mx-auto mb-6"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              การแจกจ่ายที่ยึดหลักความยุติธรรมและความเป็นธรรมตามหลักการอิสลาม
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 hover:shadow-lg transition-all transform hover:-translate-y-2">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <Scale3d className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">ความยุติธรรม</h3>
                <p className="text-gray-600 leading-relaxed">
                  ระบบการแจกจ่ายที่โปร่งใสและเป็นธรรมสำหรับทุกคน ไม่มีการเลือกปฏิบัติ
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 hover:shadow-lg transition-all transform hover:-translate-y-2">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <HandHelping className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">การให้</h3>
                <p className="text-gray-600 leading-relaxed">
                  ส่งเสริมการแบ่งปันและช่วยเหลือซึ่งกันและกันในชุมชนออนไลน์
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 hover:shadow-lg transition-all transform hover:-translate-y-2">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">ความเมตตา</h3>
                <p className="text-gray-600 leading-relaxed">
                  ดำเนินการด้วยความเมตตาและความเอื้อเฟื้อเพื่อประโยชน์ของผู้คน
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Arabic calligraphy section */}
          <div className="mt-16 text-center">
            <Card className="bg-gradient-to-r from-primary to-teal-600 text-white">
              <CardContent className="p-12">
                <div className="text-3xl mb-4" style={{ fontFamily: 'serif' }}>
                  ٱللَّٰهُ حَلَالٌ
                </div>
                <p className="text-lg opacity-90">
                  "อัลลอฮฺทรงทำให้สิ่งที่ชอบธรรมเป็นสิ่งที่อนุญาต"
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Giveaway Section */}
      <section id="giveaway" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">ระบบแจกเงิน</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-orange-500 mx-auto mb-6"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              เข้าร่วมการแจกเงินฟรีประจำวัน ระบบโปร่งใสและปลอดภัย
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Active Giveaway Card */}
            <Card className="shadow-2xl border-0">
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-2xl font-bold text-gray-900">
                    {giveaway?.title || "การแจกเงินประจำวัน"}
                  </h3>
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    ดำเนินการอยู่
                  </Badge>
                </div>
                
                <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-6 rounded-2xl mb-8">
                  <div className="text-center">
                    <div className="text-4xl font-bold mb-2">
                      ฿{giveaway?.prizeAmount?.toLocaleString() || "50,000"}
                    </div>
                    <div className="text-lg opacity-90">เงินรางวัลรวม</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">
                      {giveaway?.participantCount?.toLocaleString() || "2,847"}
                    </div>
                    <div className="text-sm text-gray-600">ผู้เข้าร่วม</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">
                      {giveaway?.winnerCount || "50"}
                    </div>
                    <div className="text-sm text-gray-600">ผู้ได้รับรางวัล</div>
                  </div>
                </div>
                
                {/* Countdown Timer */}
                {giveaway?.endTime && <CountdownTimer endTime={new Date(giveaway.endTime)} />}
                
                <Button 
                  onClick={() => scrollToSection('register-form')}
                  className="w-full bg-gradient-to-r from-primary to-emerald-700 hover:from-primary/90 hover:to-emerald-700/90 text-white py-4 text-lg font-semibold mt-8"
                >
                  <Gift className="mr-2" />
                  เข้าร่วมฟรี
                </Button>

                {/* Recent Winners */}
                {recentWinners && recentWinners.length > 0 && (
                  <div className="mt-8 pt-8 border-t border-gray-200">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">ผู้ได้รับรางวัลล่าสุด</h4>
                    <div className="space-y-3">
                      {recentWinners.slice(0, 3).map((winner) => (
                        <div key={winner.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center">
                            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center mr-3">
                              <Users className="text-white text-sm" />
                            </div>
                            <span className="font-medium text-gray-900">{winner.participantName}</span>
                          </div>
                          <span className="text-primary font-semibold">฿{winner.prizeAmount.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Registration Form */}
            <div id="register-form">
              <GiveawayForm />
            </div>
          </div>
        </div>
      </section>

      {/* Rules Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">กฎการแจก & ขั้นตอน</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-orange-500 mx-auto mb-6"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              ระบบการแจกเงินที่โปร่งใส เป็นธรรม และปลอดภัย
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-8">ขั้นตอนการเข้าร่วม</h3>
              <div className="space-y-6">
                {[
                  { step: 1, title: "ลงทะเบียน", desc: "กรอกข้อมูลส่วนตัวให้ครบถ้วนและตรวจสอบความถูกต้อง" },
                  { step: 2, title: "ยืนยันตัวตน", desc: "ยืนยันอีเมลและหมายเลขโทรศัพท์เพื่อความปลอดภัย" },
                  { step: 3, title: "รอผลการจับรางวัล", desc: "ระบบจะทำการจับรางวัลอัตโนมัติเมื่อเวลาหมด" },
                  { step: 4, title: "รับเงินรางวัล", desc: "ผู้ได้รับรางวัลจะได้รับเงินผ่านช่องทางที่เลือกไว้" }
                ].map((item, index) => (
                  <div key={index} className="flex items-start">
                    <div className={`w-10 h-10 ${item.step === 4 ? 'bg-orange-500' : 'bg-primary'} text-white rounded-full flex items-center justify-center mr-4 flex-shrink-0`}>
                      <span className="font-bold">{item.step}</span>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h4>
                      <p className="text-gray-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-8">กฎและเงื่อนไข</h3>
              <Card className="bg-gray-50">
                <CardContent className="p-8">
                  <ul className="space-y-4">
                    {[
                      "ผู้เข้าร่วมต้องมีอายุ 18 ปีขึ้นไป",
                      "หนึ่งบัญชีต่อหนึ่งคน",
                      "ข้อมูลต้องถูกต้องและครบถ้วน",
                      "การจับรางวัลเป็นไปแบบสุ่ม",
                      "เงินรางวัลจะได้รับภายใน 24 ชั่วโมง",
                      "ห้ามใช้บอทหรือระบบอัตโนมัติ"
                    ].map((rule, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="text-primary mr-3 mt-1 flex-shrink-0" size={16} />
                        <span className="text-gray-700">{rule}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Card className="mt-8 bg-yellow-50 border-yellow-200">
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <TriangleAlert className="text-yellow-600 mr-2" size={16} />
                        <span className="text-sm font-semibold text-yellow-800">หมายเหตุ</span>
                      </div>
                      <p className="text-sm text-yellow-700 mt-2">
                        บริษัทขอสงวนสิทธิ์ในการเปลี่ยนแปลงกฎการแจกได้ตลอดเวลา
                      </p>
                    </CardContent>
                  </Card>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-primary to-emerald-500 rounded-xl flex items-center justify-center">
                  <Gift className="text-white text-lg" />
                </div>
                <span className="text-2xl font-bold">PeppaPeak</span>
              </div>
              <p className="text-gray-400 leading-relaxed mb-6">
                แพลตฟอร์มแจกเงินออนไลน์ที่น่าเชื่อถือ มุ่งมั่นสร้างโอกาสให้ผู้คนได้รับเงินรางวัลฟรี
              </p>
              <div className="flex space-x-4">
                <Button variant="outline" size="icon" className="bg-gray-800 hover:bg-primary border-gray-700">
                  <Facebook size={18} />
                </Button>
                <Button variant="outline" size="icon" className="bg-gray-800 hover:bg-primary border-gray-700">
                  <Twitter size={18} />
                </Button>
                <Button variant="outline" size="icon" className="bg-gray-800 hover:bg-primary border-gray-700">
                  <Instagram size={18} />
                </Button>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-6">เมนูหลัก</h4>
              <ul className="space-y-3">
                <li><button onClick={() => scrollToSection('home')} className="text-gray-400 hover:text-white transition-colors">หน้าแรก</button></li>
                <li><button onClick={() => scrollToSection('giveaway')} className="text-gray-400 hover:text-white transition-colors">แจกเงิน</button></li>
                <li><button onClick={() => scrollToSection('allah-hala')} className="text-gray-400 hover:text-white transition-colors">Allah Hala</button></li>
                <li><button onClick={() => scrollToSection('about')} className="text-gray-400 hover:text-white transition-colors">เกี่ยวกับเรา</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-6">ช่วยเหลือ</h4>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">วิธีการใช้งาน</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">คำถามที่พบบ่อย</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">ติดต่อสนับสนุน</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">ข้อกำหนดการใช้งาน</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-6">ติดต่อเรา</h4>
              <div className="space-y-3">
                <div className="flex items-center">
                  <Mail className="text-emerald-500 mr-3" size={16} />
                  <span className="text-gray-400">support@peppapeak.com</span>
                </div>
                <div className="flex items-center">
                  <Phone className="text-emerald-500 mr-3" size={16} />
                  <span className="text-gray-400">02-123-4567</span>
                </div>
                <div className="flex items-center">
                  <Clock className="text-emerald-500 mr-3" size={16} />
                  <span className="text-gray-400">24/7 สนับสนุน</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 mt-8">
            <div className="text-center text-gray-400">
              <p>&copy; 2024 PeppaPeak. สงวนลิขสิทธิ์ทุกประการ | ออกแบบด้วยความใส่ใจ</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
