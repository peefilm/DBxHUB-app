import { useCountdown } from "@/hooks/use-countdown";

interface CountdownTimerProps {
  endTime: Date;
}

export function CountdownTimer({ endTime }: CountdownTimerProps) {
  const timeLeft = useCountdown(endTime);

  return (
    <div className="bg-gray-50 p-6 rounded-xl">
      <div className="text-center mb-4">
        <div className="text-sm text-gray-600 mb-2">เวลาที่เหลือ</div>
        <div className="grid grid-cols-4 gap-2 text-center">
          <div className="bg-primary text-white p-3 rounded-lg">
            <div className="text-xl font-bold">{timeLeft.hours.toString().padStart(2, '0')}</div>
            <div className="text-xs">ชั่วโมง</div>
          </div>
          <div className="bg-primary text-white p-3 rounded-lg">
            <div className="text-xl font-bold">{timeLeft.minutes.toString().padStart(2, '0')}</div>
            <div className="text-xs">นาที</div>
          </div>
          <div className="bg-primary text-white p-3 rounded-lg">
            <div className="text-xl font-bold">{timeLeft.seconds.toString().padStart(2, '0')}</div>
            <div className="text-xs">วินาที</div>
          </div>
          <div className="bg-primary text-white p-3 rounded-lg">
            <div className="text-xl font-bold">{timeLeft.milliseconds.toString().padStart(2, '0')}</div>
            <div className="text-xs">มิลลิ</div>
          </div>
        </div>
      </div>
    </div>
  );
}
