import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertParticipantSchema } from "@shared/schema";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Send } from "lucide-react";

const formSchema = insertParticipantSchema.extend({
  acceptTerms: z.boolean().refine(val => val === true, "กรุณายอมรับข้อกำหนดและเงื่อนไข")
}).omit({ giveawayId: true });

type FormData = z.infer<typeof formSchema>;

export function GiveawayForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      acceptTerms: false,
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: Omit<FormData, "acceptTerms">) => {
      const response = await apiRequest("POST", "/api/giveaway/register", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "ลงทะเบียนสำเร็จ!",
        description: "ขอบคุณที่เข้าร่วมการแจกเงิน",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/giveaway/active"] });
    },
    onError: (error: any) => {
      toast({
        title: "เกิดข้อผิดพลาด",
        description: error.message || "ไม่สามารถลงทะเบียนได้ในขณะนี้",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    window.open('https://www.youtube.com/watch?v=dQw4w9WgXcQ', '_blank');
  };

  return (
    <div className="bg-white rounded-3xl shadow-2xl p-8">
      <h3 className="text-2xl font-bold text-gray-900 mb-6">ลงทะเบียนเข้าร่วม</h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-semibold text-gray-700">ชื่อ-นามสกุล</FormLabel>
                <FormControl>
                  <Input placeholder="กรอกชื่อ-นามสกุล" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-semibold text-gray-700">อีเมล</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="กรอกอีเมล" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-sm font-semibold text-gray-700">เบอร์โทรศัพท์</FormLabel>
                <FormControl>
                  <Input type="tel" placeholder="กรอกเบอร์โทรศัพท์" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="acceptTerms"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel className="text-sm text-gray-600">
                    ยอมรับ<span className="text-primary hover:underline ml-1 cursor-pointer">ข้อกำหนดและเงื่อนไข</span>
                  </FormLabel>
                  <FormMessage />
                </div>
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white py-4 text-lg font-semibold"
            disabled={registerMutation.isPending}
          >
            {registerMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                กำลังลงทะเบียน...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                ลงทะเบียน
              </>
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
}
